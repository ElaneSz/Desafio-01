package pratica.polimorfismo;

public class PraticaPolimorfismo {

    public static void main(String[] args) {
        System.out.println("========================================================");
        //Questão 01
        Empregado x = new Empregado(12, "Elane", "XXX", 1200);
        Chefe y = new Chefe(13, "Elane", "XXX", 1200, 50);
        Estagiario z = new Estagiario(14, "Elane", "XXX", 1200, 300);
        System.out.println("Salário do Empregado: " + x.mostrarSalario());
        System.out.println("Salário do Empregado com aumento: " + x.aumentarSalario(10));
        System.out.println("Salário do Chefe: " + y.aumentarSalario(15));
        System.out.println("Salário do Estagiario: " + z.aumentarSalario(20));
        System.out.println("========================================================");
        //Questão 02
        Animal p2 = new Animal ("xxx", "xxx");
        Cachorro p3 = new Cachorro ("Lola", "xxx");
        Gato p4 = new Gato ("Simba", "xxx");
        System.out.println(p2.caminha());
        System.out.println(p3.late() + " " + p3.caminha());
        System.out.println(p4.mia() + " " + p4.caminha());
    }
    
}
