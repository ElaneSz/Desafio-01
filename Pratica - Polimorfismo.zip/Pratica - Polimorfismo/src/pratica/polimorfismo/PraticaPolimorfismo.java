package pratica.polimorfismo;

public class PraticaPolimorfismo {

    public static void main(String[] args) {
        
    }
    
}
