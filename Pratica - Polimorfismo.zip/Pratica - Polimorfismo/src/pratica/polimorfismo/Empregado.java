package pratica.polimorfismo;

public class Empregado {
    private int Codigo;
    private String Nome, Email;
    protected double Salario;
    
    public Empregado (int codigo, String nome, String email, double salario){
        this.Codigo = codigo;
        this.Nome = nome;
        this.Email = email;
        this.Salario = salario;
    }
    
    public double mostrarSalario(){
        return this.Salario;
    }
    
    public void aumentarSalario(double percentual){
        //return this.Salario*percentual;
    }
}
