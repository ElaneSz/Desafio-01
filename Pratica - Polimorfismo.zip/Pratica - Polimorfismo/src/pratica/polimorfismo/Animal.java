package pratica.polimorfismo;

public class Animal {
    private String Nome, Raca;
    
    public Animal (String nome, String raca){
        this.Nome = nome;
        this.Raca = raca;
    }
    public Animal (String nome){
        this.Nome = nome;
    }
    public String caminha(){
        return "- Animal caminhando -";
    }
}
