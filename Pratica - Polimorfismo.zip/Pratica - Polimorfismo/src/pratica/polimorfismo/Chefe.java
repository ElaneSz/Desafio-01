package pratica.polimorfismo;

public class Chefe extends Empregado{
    private double Beneficio;
    
    public Chefe (int codigo, String nome, String email, double salario, double beneficio){
        super(codigo, nome, email, salario);
        this.Beneficio = beneficio;
    }
    
    public double aumentarSalario(double percentual){
        return (this.Salario*percentual) + this.Beneficio;
    }
}
