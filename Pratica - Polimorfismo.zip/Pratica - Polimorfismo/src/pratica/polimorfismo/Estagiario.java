package pratica.polimorfismo;

public class Estagiario extends Empregado{
    private int Desconto;
    
    public Estagiario (int codigo, String nome, String email, double salario, int desconto){
        super(codigo, nome, email, salario);
        this.Desconto = desconto;
    }
    
    public double aumentarSalario(double percentual){
        return (this.Salario*percentual) - this.Desconto;
    }
}
