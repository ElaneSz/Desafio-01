package polimorfismo.sobrescrita;

public class Animal {
    public String emiteSom(){
        return "Qualquer som!";
    }
}
