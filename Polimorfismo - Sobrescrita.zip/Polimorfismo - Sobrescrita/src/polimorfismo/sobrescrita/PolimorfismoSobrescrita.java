package polimorfismo.sobrescrita;

public class PolimorfismoSobrescrita {

    public static void main(String[] args) {
        Animal a1 = new Animal();
        Cachorro lola = new Cachorro();
        Gato simba = new Gato();
        Galinha pintadinha = new Galinha();
        
        System.out.println("O som do animal: " + a1.emiteSom());
        System.out.println("O som do Cachorro é: " + lola.emiteSom());
        System.out.println("O som do Gato é: " + simba.emiteSom());
        System.out.println("O som da Galinha é: " + pintadinha.emiteSom());
    }
    
}
