package polimorfismo.sobrescrita;

public class Gato extends Animal{
    public String emiteSom(){
        return "MIAU! MIAU!";
    }
}
