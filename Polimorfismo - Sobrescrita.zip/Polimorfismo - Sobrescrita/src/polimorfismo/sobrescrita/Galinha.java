package polimorfismo.sobrescrita;

public class Galinha extends Animal{
    public String emiteSom(){
        return "CÓ! CÓ!";
    }
}
