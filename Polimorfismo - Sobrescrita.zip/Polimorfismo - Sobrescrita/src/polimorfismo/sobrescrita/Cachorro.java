package polimorfismo.sobrescrita;

public class Cachorro extends Animal{
    public String emiteSom(){
        return "AU! AU!";
    }
    
}
