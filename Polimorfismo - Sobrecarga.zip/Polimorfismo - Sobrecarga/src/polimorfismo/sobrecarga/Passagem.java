package polimorfismo.sobrecarga;

public class Passagem {
    private double Valor,Imposto,Seguro;
    //Não precisa de construtor, porquê ele seria "()"
    
    public double calcularVaor(double valor, double imposto){
        this.Valor = valor;
        this.Imposto = imposto;
        return this.Valor + this.Imposto;
    }
    
    public double calcularVaor(double valor, double imposto, double seguro){
        this.Valor = valor;
        this.Imposto = imposto;
        this.Seguro = seguro;
        return this.Valor + this.Imposto + this.Seguro;
    }
}
