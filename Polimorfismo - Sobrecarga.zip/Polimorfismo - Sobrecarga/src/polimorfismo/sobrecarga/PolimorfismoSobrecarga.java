package polimorfismo.sobrecarga;

public class PolimorfismoSobrecarga {

    public static void main(String[] args) {
        Passagem p1 = new Passagem();
        System.out.println("O valor da passagem sem seguro é: " + p1.calcularVaor(100, 10));
        System.out.println("O valor da passagem com seguro é: " + p1.calcularVaor(100, 10, 20));
    }
    
}
