package lista01;

public class Lista01 {

    public static void main(String[] args) {
        // Teste exercicio 01
        Bola bolinha = new Bola("amarelo","plastico",45.2);
        System.out.println("A cor da bola é: "+ bolinha.mostrarCor());
        bolinha.trocarCor("verde");
        System.out.println("A nova cor da bola é: "+ bolinha.mostrarCor());
        
        System.out.println("======================================================================");
        // Teste exercicio 02
        Quadrado quadradinho = new Quadrado (23.9);
        System.out.println("O valor do lado é: "+quadradinho.retornarLado());
        quadradinho.trocarLado(78.9);
        System.out.println("O novo valor do lado é: "+quadradinho.retornarLado());
        System.out.println("Área do quadrado: "+quadradinho.calcularArea());
        
        System.out.println("======================================================================");
        // Teste exercicio 03
        Pessoa elane = new Pessoa ("Elane",60.0,1.55,17);
        System.out.println("Olá " +elane.retornaNome());
        System.out.println("Você envelheceu 1 ano, com isso sua idade atual é:"+elane.envelhecer());
        System.out.println("Seu peso atual é:" + elane.engordar());
        System.out.println("Você emagreceu, portanto seu peso atual é: "+elane.emagrecer());
        System.out.println("Sua altura atual é: "+elane.crescer());
        System.out.println("======================================================================");
        // Teste exercicio 04
        Televisao tv = new Televisao (6,30);
        System.out.println("Canal atual: "+tv.canal());
        System.out.println("Volume atual: "+tv.volume());
        tv.alterarCanal(8);
        System.out.println("Canal alterado para o: "+tv.canal());
        tv.alterarVolume(90);
        System.out.println("Volume alterado para o: "+tv.volume());
        tv.alterarCanal(0);
        System.out.println("Canal alterado para o: "+tv.canal());
    }
    
}
