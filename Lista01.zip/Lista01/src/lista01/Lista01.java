package lista01;

public class Lista01 {
    //Aluna: Elane Souza de Oliveira
    //Turma: IA-21

    public static void main(String[] args) {
        System.out.println("=================================Exercicio 01=================================");
        // Teste exercicio 01
        Bola bolinha = new Bola("amarelo","plastico",45.2);
        System.out.println("A cor da bola é: "+ bolinha.mostrarCor());
        bolinha.trocarCor("verde");
        System.out.println("A nova cor da bola é: "+ bolinha.mostrarCor());
        
        System.out.println("=================================Exercicio 02=================================");
        // Teste exercicio 02
        Quadrado quadradinho = new Quadrado (23.9);
        System.out.println("O valor do lado é: "+quadradinho.retornarLado());
        quadradinho.trocarLado(78.9);
        System.out.println("O novo valor do lado é: "+quadradinho.retornarLado());
        System.out.println("Área do quadrado: "+quadradinho.calcularArea());
        
        System.out.println("=================================Exercicio 03=================================");
        // Teste exercicio 03
        Pessoa elane = new Pessoa ("Elane",60.0,1.55,17);
        System.out.println("Olá " +elane.retornaNome());
        System.out.println("Você envelheceu 1 ano, com isso sua idade atual é:"+elane.envelhecer());
        System.out.println("Seu peso atual é:" + elane.engordar());
        System.out.println("Você emagreceu, portanto seu peso atual é: "+elane.emagrecer());
        System.out.println("Sua altura atual é: "+elane.crescer());
        
        System.out.println("=================================Exercicio 04=================================");
        // Teste exercicio 04
        Televisao tv = new Televisao (6,30);
        System.out.println("Canal atual: "+tv.canal());
        System.out.println("Volume atual: "+tv.volume());
        tv.alterarCanal(8);
        System.out.println("Canal atual: "+tv.canal());
        tv.alterarVolume(90);
        System.out.println("Volume atual: "+tv.volume());
        tv.alterarCanal(-1);
        tv.alterarVolume(-5);
        
        System.out.println("=================================Exercicio 05=================================");
        // Teste exercicio 05
        BichinhoVirtual petite = new BichinhoVirtual ("Petite", 4, 6,12);
        System.out.println("O nome do filhote é: " + petite.retornarNome());
        System.out.println("Ele possui " + petite.retornarFome()+ " de fome.");
        System.out.println("Ele possui " + petite.retornarSaude()+ " de saúde.");
        System.out.println("Ele possui " + petite.retornarIdade()+ " anos.");
        petite.retornarHumor();
        petite.alterarNome("Fofucho");
        System.out.println("O nome do filhote é: " + petite.retornarNome());
        petite.alterarFome(1);
        System.out.println("Ele possui " + petite.retornarFome()+ " de fome.");
        petite.alterarSaude(1);
        System.out.println("Ele possui " + petite.retornarSaude()+ " de saúde.");
        petite.alterarIdade(3);
        System.out.println("Ele possui " + petite.retornarIdade()+ " anos.");
        petite.retornarHumor();
    }
    
}
