package lista01;

public class Quadrado {
    private double tamanhoLado;
    
    public Quadrado (double tamLa){
        this.tamanhoLado = tamLa;
    }
    
    public void trocarLado (double tamLa){
        this.tamanhoLado = tamLa;
    }
    
    public double retornarLado(){
        return this.tamanhoLado;
    }
    
    public double calcularArea(){
        return (this.tamanhoLado*this.tamanhoLado);
    }
}
