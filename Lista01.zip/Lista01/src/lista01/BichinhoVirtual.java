package lista01;

public class BichinhoVirtual {
    private String Nome;
    private int Fome, Saude, Idade;
    
    public BichinhoVirtual (String nome, int fome, int saude, int idade){
        this.Nome = nome;
        this.Fome = fome;
        this.Saude = saude;
        this.Idade = idade;
    }
    
    public void alterarNome (String no){
        this.Nome = no;
    }
    
    public void alterarFome (int fo){
        this.Fome = fo;
    }
    
    public void alterarSaude (int sa){
        this.Saude = sa;
    }
    
    public void alterarIdade (int ida){
        this.Idade = ida;
    }
    
    public String retornarNome(){
        return this.Nome;
    }
    
    public int retornarFome(){
        return this.Fome;
    }
    
    public int retornarSaude(){
        return this.Saude;
    }
    
    public int retornarIdade(){
        return this.Idade;
    }
    
    public void retornarHumor(){
        if (this.Fome <= 3 && this.Saude <= 5){
            System.out.println("==============================");
            System.out.println("Mau Humor!!!");
            System.out.println("==============================");
        }
        if (this.Fome > 3 && this.Saude > 5){
            System.out.println("==============================");
            System.out.println("Bom Humor!!!");
            System.out.println("==============================");
        }
    }   
}
