package lista01;

public class Televisao {
    private int canal;
    private int volume;
    
    public Televisao (int can, int volu){
        this.canal = can;
        this.volume = volu;
    }
    
    public int canal(){
        return this.canal;
    }
    
    public int volume(){
        return this.volume;
    }
    
    public void alterarVolume(int alterar){
        if (alterar < 0 || alterar > 100){
            System.out.println("==============================");
            System.out.println("Valor invalido!!!");
            System.out.println("==============================");
        }
        else{
            this.volume = alterar;
        }
    }
    
    public void alterarCanal(int alterar){
        if (alterar < 1 || alterar > 10){
            System.out.println("==============================");
            System.out.println("Valor invalido!!!");
            System.out.println("==============================");
        }
        else{
            this.canal = alterar;
        }
    }
}
