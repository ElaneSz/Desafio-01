package lista01;

public class Televisao {
    private int canal;
    private int volume;
    
    public Televisao (int can, int volu){
        this.canal = can;
        this.volume = volu;
    }
    
    public int canal(){
        return this.canal;
    }
    
    public int volume(){
        return this.volume;
    }
    
    public void alterarVolume(int alterar){
        if (this.volume < 0 && this.volume > 100){
            System.out.println("Valor invalido!!!");
        }
        else{
            this.volume = alterar;
        }
    }
    
    public void alterarCanal(int alterar){
        if (this.canal <= 0 && this.canal > 10){
            System.out.println("Valor invalido!!!");
        }
        else{
            this.canal = alterar;
        }
    }
}
