package lista01;

public class Pessoa {
    private String nome;
    private double peso, altura;
    private int idade;
    
    public Pessoa (String no, double pe, double al, int id){
        this.nome = no;
        this.peso = pe;
        this.altura = al;
        this.idade = id;
    }
    public String retornaNome (){
        return this.nome;
    }
    public int envelhecer (){
        return this.idade+1;
    }
    public double engordar (){
        return this.peso+1.0;
    }
    public double emagrecer (){
        return this.peso-2.0;
    }
    public double crescer (){
        if (this.idade < 21)
            return this.altura + 0.5;      
        return this.altura;
    }
}