package contas;

public class ContaEspecial extends ContaCorrente {
    private int limite;

    public ContaEspecial(int num, double sal, String cli, int lim) {
        super(num, sal, cli);
        this.limite = lim;
    }

    @Override
    public void retirar(double valor){
        if (valor <=(super.getSaldo() + this.limite)){
            super.setSaldo(super.getSaldo() - valor);
        }else{
             System.out.println("Saldo Insuficiente");
        }
    }

}
