package contas;

public class Contas {

    public static void main(String[] args) {
        ContaCorrente conta1 = new ContaCorrente(1, 1000, "Ana");
        ContaEspecial conta2 = new ContaEspecial(2, 2000, "Joao", 5000);
        ContaPoupanca conta3 = new ContaPoupanca(3,1000, "Claudia",1000);
        ContaInvestimento conta4 = new ContaInvestimento(4, 1000, "Cida", 8, 10);
        ContaInvestimento conta5 = new ContaInvestimento(5, 1000, "Eva", 1,10);
        //Conta Corrente
        conta1.retirar(2000);
        conta1.retirar(500);
        System.out.println("Seu saldo é: " + conta1.getSaldo());
        conta1.depositar(1000);
        System.out.println("Seu saldo é: " + conta1.getSaldo());
        System.out.println("============================================");
        //Conta Especial
        conta2.retirar(10000);
        conta2.retirar(3000);
        System.out.println("Seu saldo é: " + conta2.getSaldo());
        conta2.depositar(2000);
        System.out.println("Seu saldo é: " + conta2.getSaldo());
        System.out.println("============================================");
        //Conta Poupança
        conta3.retirar(1500);
        conta3.retirar(500);
        System.out.println("Seu saldo é: " + conta3.getSaldo());
        System.out.println("Seu saldo mínimo é: " + conta3.getSaldoMinimo());
        conta3.retirar(1500);
        System.out.println("Seu saldo é: " + conta3.getSaldo());
        System.out.println("Seu saldo mínimo é: " + conta3.getSaldoMinimo());
        conta3.atualizarSaldo();
        System.out.println("Seu saldo é: " + conta3.getSaldo());
        System.out.println("Seu saldo mínimo é: " + conta3.getSaldoMinimo());
        System.out.println("============================================");
        //Conta Investimento
        conta4.atualizarSaldo();
        System.out.println("Seu saldo é: " + conta4.getSaldo());
        conta5.atualizarSaldo();
        System.out.println("Seu saldo é: " + conta5.getSaldo());
    } 
}
