package contas;

public class Contas {

    public static void main(String[] args) {
        ContaCorrente conta1 = new ContaCorrente(1, 1000, "Ana");
        ContaEspecial conta2 = new ContaEspecial(2, 2000, "Joao", 5000);
        //Conta Corrente
        conta1.retirar(2000);
        conta1.retirar(500);
        System.out.println("Seu saldo é: " + conta1.getSaldo());
        conta1.depositar(1000);
        System.out.println("Seu saldo é: " + conta1.getSaldo());
        System.out.println("============================================");
        //Conta Especial
        conta2.retirar(10000);
        conta2.retirar(3000);
        System.out.println("Seu saldo é: " + conta2.getSaldo());
        conta2.depositar(2000);
        System.out.println("Seu saldo é: " + conta2.getSaldo());
        System.out.println("============================================");
    }
    
}
