package contas;

public class ContaCorrente {
    private int numero;
    private double saldo;
    private String cliente;

    public ContaCorrente (int num, double sal,String cli){
        this.numero = num;
        this.saldo = sal;
        this.cliente = cli;
    }

    public void depositar(double valor){
        this.saldo = this.saldo + valor;
    }

    public void retirar(double valor){
        if (valor <= this.saldo) {
            this.saldo = this.saldo - valor;
        } else {
            System.out.println("Saldo Insuficiente");
        }
    }
    
    public void setSaldo (double valor){
        this.saldo = this.saldo + valor;
    }
    
    public double getSaldo(){
        return this.saldo;
    }
}
