package atividade.pkg01.elane;

public class Pessoa {
    private String nome;
    private double peso, altura;
    private int idade;
    
    public Pessoa (String no, double pe, double al, int id){
        this.nome = no;
        this.peso = pe;
        this.altura = al;
        this.idade = id;
    }
    
    
}
