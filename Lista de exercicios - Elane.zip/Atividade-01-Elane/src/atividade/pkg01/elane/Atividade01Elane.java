package atividade.pkg01.elane;

public class Atividade01Elane {

    public static void main(String[] args) {
        // Teste exercicio 01
        Bola bolinha = new Bola("amarelo","plastico",45.2);
        System.out.println("A cor da bola é: "+ bolinha.mostrarCor());
        bolinha.trocarCor("verde");
        System.out.println("A nova cor da bola é: "+ bolinha.mostrarCor());
        
        System.out.println("======================================================================");
        // Teste exercicio 02
        Quadrado quadradinho = new Quadrado (23.9);
        System.out.println("O valor do lado é: "+quadradinho.retornarLado());
        quadradinho.trocarLado(78.9);
        System.out.println("O novo valor do lado é: "+quadradinho.retornarLado());
        System.out.println("Área do quadrado: "+quadradinho.calcularArea());
        
        System.out.println("======================================================================");
        // Teste exercicio 03
    }
}
